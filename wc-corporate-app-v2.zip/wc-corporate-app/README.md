# WC Corporate App 📱

App móvil para **WC Corporate Editor** — editor de documentos profesional con IA para Costa Rica.

## Tecnología
- **Expo** (SDK 51) + React Native
- **WebView** envolviendo el editor web
- **EAS Build** para compilar Android / iOS

## URL del editor
```
https://kacn1z-del.github.io/wc-editorpro/
```

## Requisitos previos
- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- EAS CLI: `npm install -g eas-cli`
- Cuenta en [expo.dev](https://expo.dev)

## Instalación local

```bash
git clone https://github.com/kacn1z-del/wc-corporate-app.git
cd wc-corporate-app
npm install
npx expo start
```

## Build con EAS

### APK de prueba (Android)
```bash
eas build --platform android --profile preview
```

### Build de producción (App Bundle para Play Store)
```bash
eas build --platform android --profile production
```

### Build iOS
```bash
eas build --platform ios --profile production
```

### Ambas plataformas a la vez
```bash
eas build --platform all --profile production
```

## Primer uso con EAS

```bash
# Login en tu cuenta expo
eas login

# Inicializar EAS en el proyecto
eas build:configure

# Luego construir
eas build --platform android --profile preview
```

## Funcionalidades incluidas

✅ Editor de documentos completo (Word-style)
✅ Sibö IA (inteligencia artificial costarricense)
✅ Cálculos legales CR (CCSS, liquidación, renta 2026)
✅ Traductor lenguas indígenas
✅ Generador de imágenes IA
✅ Templates corporativos
✅ Firebase (colaboración en tiempo real)
✅ Exportar PDF / Word / EPUB
✅ Botón atrás Android funciona dentro del editor

## Estructura del proyecto

```
wc-corporate-app/
├── App.tsx          # Componente principal con WebView
├── index.js         # Punto de entrada
├── app.json         # Configuración Expo
├── eas.json         # Configuración EAS Build
├── babel.config.js  # Babel
├── tsconfig.json    # TypeScript
└── assets/          # Íconos y splash (agregar manualmente)
    ├── icon.png         (1024×1024)
    ├── splash.png       (1284×2778)
    ├── adaptive-icon.png (1024×1024)
    └── favicon.png      (32×32)
```

## Assets requeridos

Antes de compilar, colocá estas imágenes en `/assets/`:

| Archivo | Tamaño | Uso |
|---------|--------|-----|
| `icon.png` | 1024×1024 | Ícono de la app |
| `splash.png` | 1284×2778 | Pantalla de carga |
| `adaptive-icon.png` | 1024×1024 | Ícono adaptable Android |
| `favicon.png` | 32×32 | Web |

> 💡 Podés usar EAS para generarlos si tenés el ícono base en alta resolución.

---

Desarrollado por **Keny Chinchilla Navarro** 🇨🇷
